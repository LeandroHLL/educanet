<?php

/**
 * Name: Simple PHP Login & Registration Script
 * Version: 0.1.1
 * Author: Tutorials Class
 * Website: www.tutorialsclass.com
 * Tutorial: https://tutorialsclass.com/code/simple-php-login-registration-script
 */
?>

<html>

<head>

<body>

    <div>
        Welcome to Simple Login & Registration Script in PHP. This script use minimum PHP, MySQL, and HTML that is easy to understand. Try and Learn PHP login/Registration prepared by www.TutorialsClass.com
    </div>
    <br /> <br />
    <div>
        <a href="login.php"> Login</a> | <a href="register.php"> Register</a>
    </div>

</body>

</html>